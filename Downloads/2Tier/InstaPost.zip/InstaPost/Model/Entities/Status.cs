﻿namespace UploadImage.Models
{
    public class Status
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
    }
}
