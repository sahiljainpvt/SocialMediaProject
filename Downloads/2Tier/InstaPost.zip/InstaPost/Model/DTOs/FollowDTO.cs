﻿namespace Core.DTOs
{
    public class FollowDTO
    {
        public int Id { get; set; }
        public string FollowerId { get; set; }
        public string FollowedUserId { get; set; }
    }
}
